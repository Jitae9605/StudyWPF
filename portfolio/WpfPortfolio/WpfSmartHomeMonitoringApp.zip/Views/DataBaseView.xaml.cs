﻿using System.Windows.Controls;

namespace WpfSmartHomeMonitoringApp.Views
{
	/// <summary>
	/// DataBaseView.xaml에 대한 상호 작용 논리
	/// </summary>
	public partial class DataBaseView : UserControl
	{
		public DataBaseView()
		{
			InitializeComponent();
		}
	}
}
