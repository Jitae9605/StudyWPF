﻿using Caliburn.Micro;

namespace WpfSmartHomeMonitoringApp.ViewModels
{
	public class HistoryViewModel : Screen
	{
		public HistoryViewModel()
		{

		}
	}
}
