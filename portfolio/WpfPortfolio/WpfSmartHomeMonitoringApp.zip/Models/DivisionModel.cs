﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfSmartHomeMonitoringApp.Models
{
	public class DivisionModel
	{
		public int KeyVal { get; set; }
		public string DivisionVal { get; set; }
	}
}
