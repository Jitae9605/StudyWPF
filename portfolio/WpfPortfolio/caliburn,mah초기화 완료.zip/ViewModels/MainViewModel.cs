﻿using Caliburn.Micro;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace WpfSmartHomeMonitoringApp.ViewModels
{
	public class MainViewModel : Screen
	{
		public MainViewModel()
		{
			//MessageBox.Show("MVVM Start!");
		}
	}
}
